chrome.action.onClicked.addListener(async (tab) => {
    const currentUrl = tab.url;
    // 匹配数字并递增
    const newUrl = currentUrl.replace(/(\d+)(?=\.html$)/, (match, p1) => {
      return String(Number(p1) + 1);
    });
    
    // 跳转到新URL
    if (newUrl !== currentUrl) {
      await chrome.tabs.update(tab.id, { url: newUrl });
    }
  });