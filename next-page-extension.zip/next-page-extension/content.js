// 创建页面按钮
const btn = document.createElement('button');
btn.className = 'next-page-btn';
btn.textContent = 'Next Page →';

// 点击事件处理
btn.addEventListener('click', async () => {
  const currentUrl = window.location.href;
  const newUrl = currentUrl.replace(/(\d+)(?=\.html$)/, (match, p1) => {
    return String(Number(p1) + 1);
  });
  
  if (newUrl !== currentUrl) {
    window.location.href = newUrl;
  }
});

// 仅当URL包含数字.html时显示按钮
if (/\d+\.html$/.test(window.location.href)) {
  document.body.appendChild(btn);
}